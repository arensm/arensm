# PogoPlug E02 V3.3 / DE

USB-Player für PogoPlug E02 (Kirkwood, ARMv5), auf Basis der veröffentlichten V3.2. Squeezelite, klassisches AirPlay, Europe/Berlin und die LED-Anzeige bleiben erhalten. Nach jedem Start läuft Squeezelite; das Webinterface schaltet zwischen den beiden Playern um.

## Neu im Zahnrad-Menü

- LMS-Server: Hostname oder IP-Adresse, optional mit Port; leer aktiviert automatische Suche. Speicherung als `LMS_SERVER` in `/boot/squeezelite.conf`.
- Audio-Gerät: Auswahlliste aus `squeezelite -l`, beim Öffnen des Setups neu eingelesen. `default` bleibt verfügbar und ist voreingestellt. Speicherung als `AUDIO_DEVICE` in `/boot/squeezelite.conf`.
- Öffentliche SSH-Schlüssel: Das Textfeld zeigt und ersetzt `/root/.ssh/authorized_keys`. Ein öffentlicher RSA-, Ed25519- oder ECDSA-Schlüssel pro Zeile, ohne Optionen. Mindestens ein gültiger Schlüssel muss verbleiben. Den eigenen Zugangsschlüssel beibehalten; keine privaten Schlüssel eingeben.
- Neu starten und Ausschalten mit Bestätigung. Zum Einschalten nach Poweroff muss die Stromversorgung kurz getrennt und wieder verbunden werden.

LMS-/Audio-Änderungen starten einen laufenden Squeezelite kurz neu. Alle neuen Beschriftungen sind auf Deutsch und Englisch vorhanden. Die Auswahl DE/EN befindet sich neben dem Zahnrad. Die öffentlichen Schlüssel im ausgelieferten Image entsprechen unverändert V3.2.

Das Webinterface hat wie V3.2 keine Anmeldung. Wer es im Netzwerk erreichen kann, kann auch Einstellungen und SSH-Zugänge ändern. Es ist für ein vertrauenswürdiges lokales Netzwerk vorgesehen.

## USB-Stick schreiben

Das ZIP enthält ein vollständiges Diskimage mit exakt 100.000.000 Bytes, MBR und aktiver ext2-Partition. Das Ziel muss mindestens 100 MB groß sein. Die Partition wächst nicht automatisch auf die Stickgröße.

Nach dem Entpacken unter Linux das Zielgerät sorgfältig prüfen; der folgende Befehl überschreibt dessen Partitionstabelle und bisherige Dateisystemdaten:

```sh
sudo dd if=pogo-e02-v3.3-ext2-100MB.img of=/dev/sdX bs=4M conv=fsync status=progress
sync
```

`/dev/sdX` ist der gesamte USB-Stick. Danach sicher auswerfen, am E02 anschließen und starten. Voraussetzung ist ein U-Boot mit eingerichtetem USB-Start. Der Kernel und seine USB-Rootparameter stammen aus dem kompatiblen V3.2-USB-Profil. Dieses USB-Image ist kein NAND- oder Bootloader-Installer.

Das Webinterface ist unter der DHCP-Adresse des E02 erreichbar. Zahnrad öffnen, gewünschte Werte einstellen und **Speichern** wählen.

## Prüfung und Build

Das ext2-Dateisystem, alle regulären Dateien, Links und Inode-Rechte wurden geprüft. Der neue Helfer ist für ARM926/ARMv5-Soft-Float übersetzt und unter ARM926-Emulation geprüft. Schlüssel-/Konfigurationsvalidierung und die Systemaktionen wurden isoliert mit Ersatzbefehlen getestet. V3.3 wurde noch nicht auf einem physischen E02 gebootet. Laufende Geräte wurden für diesen Build nicht verändert.

Das Quellpaket enthält das neue externe Buildroot-Projekt, die festgehaltene V3.2-Kernelkonfiguration und den Releasebauer. Mit einer vorhandenen Buildroot-2026.08-Umgebung und ARMv5-Musl-Toolchain kann das vollständige System über `make configure` und `make build` gebaut werden; `BASE`, `BR`, `DL` und der externe Toolchainpfad sind gegebenenfalls anzupassen. `make web-helper` übersetzt nur den neuen Helfer. Der Releasebauer `scripts/build-v33-release.py` verwendet das vollständige veröffentlichte V3.2-Release inklusive `usb-portable-kernel/` als eingefrorene Basis; Pfade lassen sich über `--base-release` und `--release` setzen.

# PogoPlug E02 V3.3 / EN

USB player for PogoPlug E02 (Kirkwood, ARMv5), based on the published V3.2 release. Squeezelite, classic AirPlay, Europe/Berlin and LED behavior are retained. Squeezelite starts after each boot; the web interface switches between the two players.

## New settings

- LMS server: hostname or IP address, optionally with port; leave empty for discovery. Saved as `LMS_SERVER` in `/boot/squeezelite.conf`.
- Audio device: selection populated from `squeezelite -l` whenever settings open. `default` remains available and is selected initially. Saved as `AUDIO_DEVICE` in `/boot/squeezelite.conf`.
- Public SSH keys: the text area displays and replaces `/root/.ssh/authorized_keys`. One public RSA, Ed25519 or ECDSA key per line, without options; at least one valid key must remain. Keep your own access key and never paste private keys.
- Reboot and power off with confirmation. Disconnect and reconnect power to start the device after poweroff.

Changing LMS/audio settings briefly restarts a running Squeezelite. All new labels are available in German and English; the DE/EN switch is next to the gear. The image retains exactly the same authorized public keys as V3.2.

As in V3.2, the web interface has no login. Anyone able to reach it over the network can change settings and SSH access. It is intended for a trusted local network.

## Write the USB drive

Extract the ZIP. The image is exactly 100,000,000 bytes and contains an MBR with one active ext2 partition. The drive must be at least 100 MB; the partition does not expand automatically. Verify the target carefully: this command overwrites its partition table and previous filesystem data.

```sh
sudo dd if=pogo-e02-v3.3-ext2-100MB.img of=/dev/sdX bs=4M conv=fsync status=progress
sync
```

Use the whole USB drive as `/dev/sdX`, safely eject it, connect it to the E02 and boot. A U-Boot already configured for USB boot is required. The compatible V3.2 USB kernel payload and root parameters are retained. This USB image does not install NAND or U-Boot.

Open the E02 DHCP address in a browser, open the gear menu, select settings and press **Save**.

The image filesystem, files, links and ownership/modes were verified. The new ARMv5 helper was checked under ARM926 emulation. Configuration/key validation and shutdown commands were tested in isolation with harmless substitute commands. V3.3 has not yet been booted on physical E02 hardware. No live device was updated by this build.
